//
//  Utils.swift
//  RoyalRajasthan
//
//  Created by Chintan patel on 02/12/17.
//  Copyright © 2017 Hardik. All rights reserved.
//

import Foundation

class Utils
{
    static func getCityWithValues(dictLead:NSDictionary) -> city{
        let tmpOBJ = city.init()
        
        tmpOBJ.cityID =   dictLead["cityID"] as!  NSString
        tmpOBJ.name =   dictLead["name"] as! NSString
        tmpOBJ.imagename =   dictLead["imagename"] as! NSString
        tmpOBJ.overview =   dictLead["overview"] as! NSString
        tmpOBJ.famousfood =   dictLead["famousfood"] as! NSString
        tmpOBJ.bestvisittime =   dictLead["bestvisittime"] as! NSString
        tmpOBJ.tagline =   dictLead["tagline"] as! NSString
        tmpOBJ.lati =   dictLead["lati"] as! NSString
        tmpOBJ.longi =   dictLead["longi"] as! NSString
        
        return tmpOBJ
    }
    
    static func getTravelsWithValues(dictLead:NSDictionary) -> travels{
        let tmpOBJ = travels.init()
        //    CREATE TABLE "travels" ("travelsID" INTEGER PRIMARY KEY AUTOINCREMENT, "logoimage" TEXT, "name" TEXT, "phone" TEXT, "images" TEXT, "email" TEXT)
        tmpOBJ.travelsID =   dictLead["travelsID"] as! NSString
        tmpOBJ.logoimage =   dictLead["logoimage"] as! NSString
        tmpOBJ.name =   dictLead["name"] as! NSString
        tmpOBJ.phone =   dictLead["phone"] as! NSString
        tmpOBJ.email =   dictLead["email"] as! NSString
        
        return tmpOBJ
    }

}

