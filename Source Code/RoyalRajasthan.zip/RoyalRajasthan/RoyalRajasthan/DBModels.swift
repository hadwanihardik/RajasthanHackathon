//
//  DBModels.swift
//  RoyalRajasthan
//
//  Created by Chintan patel on 02/12/17.
//  Copyright © 2017 Hardik. All rights reserved.
//

import Foundation
class city: NSObject {
    //private static let _sharedInstance = LeadListModel()
    
//    CREATE TABLE "city" ("cityID" INTEGER PRIMARY KEY AUTOINCREMENT, "name" TEXT, "imagename" TEXT, "overview" TEXT, "famousfood" TEXT, "bestvisittime" TEXT, "tagline" TEXT, "lati" TEXT, "longi" TEXT)
    
    
    var cityID : NSString!
    var name : NSString!
    var imagename : NSString!
    var overview : NSString!
    var famousfood : NSString!
    var bestvisittime : NSString!
    var tagline : NSString!
    var lati : NSString!
    var longi : NSString!
    
    
    //    class func sharedInstance() -> LeadListModel {
    //        return _sharedInstance
    //    }
    
    
}


class travels: NSObject {
    //private static let _sharedInstance = LeadListModel()
    
    //   CREATE TABLE "travels" ("travelsID" INTEGER PRIMARY KEY AUTOINCREMENT, "logoimage" TEXT, "name" TEXT, "phone" TEXT, "images" TEXT, "email" TEXT)
    
    
    var travelsID : NSString!
    var logoimage : NSString!
    var name : NSString!
    var phone : NSString!
    var images : NSString!
    var email : NSString!
    //    class func sharedInstance() -> LeadListModel {
    //        return _sharedInstance
    //    }
    
    
}

func getCityWithValues(dictLead:NSDictionary) -> city{
    let tmpOBJ = city.init()
    
    tmpOBJ.cityID =   dictLead["cityID"] as! NSString
    tmpOBJ.name =   dictLead["name"] as! NSString
    tmpOBJ.imagename =   dictLead["imagename"] as! NSString
    tmpOBJ.overview =   dictLead["overview"] as! NSString
    tmpOBJ.famousfood =   dictLead["famousfood"] as! NSString
    tmpOBJ.bestvisittime =   dictLead["bestvisittime"] as! NSString
    tmpOBJ.tagline =   dictLead["tagline"] as! NSString
    tmpOBJ.lati =   dictLead["lati"] as! NSString
    tmpOBJ.longi =   dictLead["longi"] as! NSString
    
    return tmpOBJ
}


